<img class="h-12 w-12" src="{{ Vite::asset('resources/img/ketkor_logo.webp') }}" alt="Két Kör Kft.">

<?php echo e($slot); ?>

<?php /**PATH C:\Users\Tulajdonos\Desktop\ketkor_\resources\views/vendor/mail/text/table.blade.php ENDPATH**/ ?>
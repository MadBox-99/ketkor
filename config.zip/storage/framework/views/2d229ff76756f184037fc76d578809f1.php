<?php $actionRulesClass = app('PowerComponents\LivewirePowerGrid\Components\Rules\RulesController'); ?>

<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'livewire-powergrid::components.table-base','data' => ['theme' => $theme->table,'readyToLoad' => $readyToLoad]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('livewire-powergrid::table-base'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['theme' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($theme->table),'ready-to-load' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($readyToLoad)]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo $__env->make('livewire-powergrid::components.table.tr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('loading', null, []); ?> 
        <?php echo $__env->make('livewire-powergrid::components.table.tr', ['loading' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('body', null, []); ?> 
        <!--[if BLOCK]><![endif]--><?php if($this->hasColumnFilters): ?>
            <?php echo $__env->make('livewire-powergrid::components.inline-filters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

        <!--[if BLOCK]><![endif]--><?php if(is_null($data) || count($data) === 0): ?>
            <?php echo $__env->make('livewire-powergrid::components.table.th-empty', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->renderWhen($headerTotalColumn, 'livewire-powergrid::components.table-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!--[if BLOCK]><![endif]--><?php if(!isset($row->{$checkboxAttribute}) && $checkbox): ?>
                    <?php throw new Exception('To use checkboxes, you must define a unique key attribute in your data source.') ?>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                <?php
                    $rowId = data_get($row, $primaryKey);

                    $class = $theme->table->trBodyClass;

                    $rulesValues = $actionRulesClass->recoverFromAction($row, 'pg:rows');

                    $applyRulesLoop = true;

                    $trAttributesBag = new \Illuminate\View\ComponentAttributeBag();
                    $trAttributesBag = $trAttributesBag->merge(['class' => $class]);

                    if (method_exists($this, 'actionRules')) {
                        $applyRulesLoop = $actionRulesClass->loop($this->actionRules($row), $loop);
                    }

                    if (filled($rulesValues['setAttributes']) && $applyRulesLoop) {
                        foreach ($rulesValues['setAttributes'] as $rulesAttributes) {
                            $trAttributesBag = $trAttributesBag->merge([
                                $rulesAttributes['attribute'] => $rulesAttributes['value'],
                            ]);
                        }
                    }
                ?>

                <!--[if BLOCK]><![endif]--><?php if(isset($setUp['detail'])): ?>
                    <tbody
                        wire:key="tbody-<?php echo e($row->{$primaryKey}); ?>"
                        <?php echo e($trAttributesBag); ?>

                        x-data="{ detailState: <?php if ((object) ('setUp.detail.state.' . $row->{$primaryKey}) instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('setUp.detail.state.' . $row->{$primaryKey}->value()); ?>')<?php echo e('setUp.detail.state.' . $row->{$primaryKey}->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('setUp.detail.state.' . $row->{$primaryKey}); ?>')<?php endif; ?> }"
                    >
                        <?php echo $__env->make('livewire-powergrid::components.row', ['rowIndex' => $loop->index + 1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <tr
                            x-show="detailState"
                            style="<?php echo e($theme->table->trBodyStyle); ?>"
                            <?php echo e($trAttributesBag); ?>

                        >
                            <?php echo $__env->make('livewire-powergrid::components.table.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </tr>
                    </tbody>
                <?php else: ?>
                    <tr
                        wire:key="tbody-<?php echo e($row->{$primaryKey}); ?>"
                        style="<?php echo e($theme->table->trBodyStyle); ?>"
                        <?php echo e($trAttributesBag); ?>

                    >
                        <?php echo $__env->make('livewire-powergrid::components.row', ['rowIndex' => $loop->index + 1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </tr>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

                <?php echo $__env->renderWhen(isset($setUp['responsive']), 'livewire-powergrid::components.expand-container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->

            <?php echo $__env->renderWhen($footerTotalColumn, 'livewire-powergrid::components.table-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Tulajdonos\Desktop\ketkor_\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/table.blade.php ENDPATH**/ ?>